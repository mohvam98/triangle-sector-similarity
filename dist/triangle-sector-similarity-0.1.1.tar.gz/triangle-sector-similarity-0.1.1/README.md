Triangle Area - Sector Area Similarity
It takes two vectors as an input and prints and can return Cosine Similarity, Eucledian Distance, Triangle Area - Sector Area Similarity.

Installation
pip install triangle-sector-similarity

How to use it?
import triangle-sector-similarity
vec1 = [1,2,3]
vec2 = [2,4,5]
ts_ss = triangle-sector-similarity.TS_SS(vec1, vec2)


License
© 2021 mohan98

This repository is licensed under the MIT license. See LICENSE for details.